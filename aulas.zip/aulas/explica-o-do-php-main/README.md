# explica-o-do-php
Atividade do curso técnico de informática do módulo de programação
