<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Cadastro 1</title>
    </head>
    <body>
        <form>
            <h1>Pagina de cadastro 1</h1>
            <label for="nome" id="nome">Nome:</label>
            <input type="text" id="nome" name="nome" placeholder="Digite seu nome" required></input><br>
            <!--DIVISÃO-->
            <label for="masculino">Sexo:</label>
            <input type="radio" for="sexo" id="masculino" name="masculino" value="masculino">Masculino</input>
            <input type="radio" for="sexo" id="feminino" name="faminino" value="masculino">Feminino</input>
        </form>
    </body>
</html>