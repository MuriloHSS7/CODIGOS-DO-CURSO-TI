<!DOCTYPE html>
<html>
    <header>
        <title>Media do aluno</title>
    </header>
    <body>
        <?php
        echo"Olá mundo!";
            $nota1 = 7; echo"<br><br>";
            $nota2 = 8;
            $nota3 = 9;
            $nota4 = 10;
            echo"Nota 1". var_dump(7); echo"<br>";
            echo"Nota 2". var_dump(8); echo"<br>";
            echo"Nota 3". var_dump(9); echo"<br>";
            echo"Nota 4". var_dump(10); echo"<br>";
        ?>
        <?php
        
        ?>
    </body>
</html>