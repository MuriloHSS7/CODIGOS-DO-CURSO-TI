<!DOCTYPE html>
<html>
    <header>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial
        <title>Media do aluno</title>
    </header>
    <body>
        <?php
            $nota1 = 7;
            $nota2 = 8;
            $nota3 = 9;
            $nota4 = 10;
            var_dump("resultado");
        ?>
    </body>
</html>