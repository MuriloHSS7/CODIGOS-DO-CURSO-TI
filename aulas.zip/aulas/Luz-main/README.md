# Luz
Atividade 2 do curso técnico
