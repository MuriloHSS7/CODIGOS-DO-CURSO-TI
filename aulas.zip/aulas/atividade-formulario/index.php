<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Formulario</title>
    </head>
    <body>
        <form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
            Name: <input type="text" name="nome" placeholder="Digite seu nome" required>
            <br>
            E-mail: <input type="email" name="email" placeholder="Digite seu email" required>
            <br>
            Senha: <input type="password" name="senha" placeholder="Digite sua senha" required>
            <br>
            <select>
                <option value="Selecione um estado">Selecione um estado</option>
                <option value="Distrito-Federal" name="DF">DF</option>
                <option value="São Paulo" name="SP">SP</option>
                <option value="Santa Catarina" name="SC">SC</option>
                <option value="Rio de Janeiro" name="RJ">RJ</option>
                <option value="Rondônia" name="RO">RO</option>
                <option value="Rio Grande do Sul" name="RS">RS</option>
            </select>
            <br>
            Envie para nós, sua sugestão<br>
            ou crítica sobre o site:<br>
            <textarea rows="5" cols="20" placeholder="Digite a sua mensagem..."></textarea><br>
            Marque o(s) laboratório(s) que você deseja receber informações:<br>
                <input type="checkbox" id="LAFES" name="LAFES" value="laboratório">
                <label for="LAFES">Laboratório de ferramentas para desenvolvimento de sistemas - LAFES</label><br>
                <!---->
                <input type="checkbox" id="LGR" name="LGR" value="laboratório">
                <label for="LGR">Laboratório de gestão de redes - LGR</label><br>
                <!---->
                <input type="checkbox" id="LIS" name="LIS" value="laboratório">
                <label for="LIS">Laboratório de integração de sistemas - LIS</label><br>
                <!---->
                <input type="checkbox" id="LQS" name="LQS" value="laboratório">
                <label for="LQS">Laboratório de qualidade de software - LQS</label><br>
                <p>você aceita receber outras informações sobre cursos de extensão da unisinos?</p>
                <input type="radio" id="sim" name="sim" value="sim">
                <label for="sim">sim</label>
                <input type="radio" id="nao" name="nao" value="nao">
                <label for="nao">não</label>
                <br>
                <button>Enviar os dados acima</button><button>Limpar</button>
        </form>
        <?php
            if($_SERVER["REQUEST_METHOD"] == "POST"){
                $nome = $_POST['nome'];
                $email = $_POST['email'];
                $senha = $_POST['senha'];
                $DF = $_POST[''];

                if(empty($name)){
                    echo"Este campo está vazio";
                } else {
                    echo $name;
                }
            }
        ?>
    </body>
</html>