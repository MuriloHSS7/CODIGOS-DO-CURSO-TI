# if_e_else_PHP
Atividade do curso técnico de informática do módulo de programação

Faça um arquivo php conforme utilizamos nas ultimas aulas e faça o seguinte exercício:
Um aluno só pode usar o medicamento se for maior igual a 16 de idade, então se a idade for acima de 65 o uso tem que ser com restrições, se abaixo de 10 é proibido o uso do medicamento.
