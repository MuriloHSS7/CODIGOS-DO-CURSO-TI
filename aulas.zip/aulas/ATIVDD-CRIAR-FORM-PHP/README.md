# ATIVDD-CRIAR-FORM-PHP
ATIVIDADE DO CURSO TÉCNICO DE INFORMÁTICA DO MÓDULO DE PROGRAMAÇÃO

Criar um formulário em php html e css com os campos (nome completo, CPF, e-mail e telefone) enviando os dados do mesmo para o banco de dados mysql e depois crie um botão para buscar as informações inseridas do banco de dados
