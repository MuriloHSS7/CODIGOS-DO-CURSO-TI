<?php

    $host = 'localhost';
    $username = 'root';
    $password = '';

    // Crir PDO dbname
    try {
        $pdo = new PDO("mysql:host=$host", $username, $password);
        // conf PDO modo erro
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "CREATE DATABASE MEUBDDFORM";
        $pdo->exec($sql);
        echo "Criado com sucesso meu BD <br>";
        
    } catch (PDOException $e) {
        echo $sql . "<br>" . $e->getMessage();
    }

    // fechar porta de acesso 
    // mysqli $conn->close();

    $pdo = null;
?>