<?php
    $host = 'localhost';
    $username = 'root';
    $password = '';
    $dbname = 'MEUBDFORM';
    
    try {
        
        $pdo = new PDO("mysql:host=$host", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
        $pdo->exec("CREATE DATABASE IF NOT EXISTS $dbname");
        echo "criado com sucesso! Banco de dados -| $dbname |-<br>";
    
        $pdo->exec("USE $dbname");
    
        $sql = "CREATE TABLE IF NOT EXISTS MINHATABELA (
            id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(80) NOT NULL,
            cpf VARCHAR(11) NOT NULL UNIQUE,
            email VARCHAR(100),
            telefone VARCHAR(11)
        )";
        $pdo->exec($sql);
        echo "criada com sucesso! Tabela -| MINHATABELA |-<br>";

    } catch (PDOException $e) {
        echo "Erro: " . $e->getMessage();
    }
    
    $pdo = null;
?>