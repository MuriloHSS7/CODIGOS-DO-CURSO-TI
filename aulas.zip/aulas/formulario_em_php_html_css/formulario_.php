<?php
    // Coletar valores do campos de entrada
    if($_SERVER["REQUEST_METHOD"]== "POST"){
        $name = $_POST['nome'];
        $cpf = $_POST['cpf'];
        $email = $_POST['email'];
        $tel = $_POST['tel']; 

        if (empty($name) || empty($cpf) || empty($email) || empty($tel)){
            echo "Nome ou CPF ou E-mail ou Telefone está vazio";
        }
        else{
            echo "Nome completo: " . $nome . "<br>";
            echo "CPF: " . $cpf . "<br>";
            echo "E-mail: " . $email . "<br>";
            echo "Telefone: " . $tel . "<br>";
        }
    }

?>