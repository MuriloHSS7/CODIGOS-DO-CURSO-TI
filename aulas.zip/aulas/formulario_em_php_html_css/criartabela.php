<?php

    $host = 'localhost';
    $username = 'root';
    $password = '';
    $dbname = "meubd";

    // Crir PDO dbname
    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        // conf PDO modo erro
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "CREATE TABLE MyGuest (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        nome VARCHAR(50) NOT NULL,
        cpf VARCHAR(30) NOT NULL,
        email VARCHAR(50),
        telefone VARCHAR(30) NOT NULL,
        reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)";
        $pdo->exec($sql);
        echo "Criado com sucesso meu BD <br>";
        
    } catch (PDOException $e) {
        echo $sql . "<br>" . $e->getMessage();
    }

    // fechar porta de acesso 
    // mysqli $conn->close();

    $pdo = null;
?>