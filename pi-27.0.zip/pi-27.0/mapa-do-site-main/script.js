// Função para mudar a cor da borda da imagem
function changeBorderColor(color) {
    const image = document.getElementById('mapImage');
    image.style.borderColor = color;
}

// Função para resetar a borda da imagem para o padrão
function resetBorderColor() {
    const image = document.getElementById('mapImage');
    image.style.borderColor = '#bec1c2'; // cinza
}

// Adicionando eventos para cada área do mapa de imagem
document.querySelector('.playstation').addEventListener('mouseover', function() {
    changeBorderColor('blue'); // Bordo azul para PlayStation
});

document.querySelector('.xbox').addEventListener('mouseover', function() {
    changeBorderColor('green'); // Bordo verde para Xbox
});

document.querySelector('.perifericos').addEventListener('mouseover', function() {
    changeBorderColor('orange'); // Bordo laranja para Periféricos
});

document.querySelector('.inicio').addEventListener('mouseover', function() {
    changeBorderColor('red'); // Bordo vermelha para Página de Início
});

document.querySelector('.sobre').addEventListener('mouseover', function() {
    changeBorderColor('purple'); // Bordo roxa para Sobre
});

document.querySelector('.produtos').addEventListener('mouseover', function() {
    changeBorderColor('yellow'); // Bordo amarela para Produtos
});

document.querySelector('.mapa').addEventListener('mouseover', function() {
    changeBorderColor('pink'); // Bordo rosa para Mapa do Site
});

document.querySelector('.login').addEventListener('mouseover', function() {
    changeBorderColor('cyan'); // Bordo ciana para Login
});

document.querySelector('.cadastro').addEventListener('mouseover', function() {
    changeBorderColor('brown'); // Bordo marrom para Cadastro
});

// Resetar a borda quando o mouse sair de qualquer área
document.querySelectorAll('.area').forEach(function(area) {
    area.addEventListener('mouseout', resetBorderColor);
});
